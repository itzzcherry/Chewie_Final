import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  Image,
  TextInput,
  FlatList,
  StyleSheet,
  Alert,
  TouchableOpacity,
  Keyboard,
  ScrollView,
  ImageBackground,
  ActivityIndicator,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import MapView, { Marker, Callout} from 'react-native-maps';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';


const neighborhoods = {
  'Bayanan': { latitude: 14.3883, longitude: 121.0494 },
  'Bayanan Proper': { latitude: 14.3885, longitude: 121.0497 }, // close to Bayanan
  'Buli': { latitude: 14.4340, longitude: 121.0415 },
  'Cupang': { latitude: 14.4132, longitude: 121.0464 },
  'Putatan': { latitude: 14.4126, longitude: 121.0480 },
  'Alabang': { latitude: 14.4135, longitude: 121.0511 },
  'Poblacion': { latitude: 14.4109, longitude: 121.0480 },
  'Tunasan': { latitude: 14.3630, longitude: 121.0567 },
  'Sucat': { latitude: 14.4420, longitude: 121.0540 },
};


const formatDateTime = (date) => {
  return new Intl.DateTimeFormat('en-US', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(date);
};

export default function App() {
  const [userArea, setUserArea] = useState(Object.keys(neighborhoods)[0]);
  const [description, setDescription] = useState('');
  const [reportLocation, setReportLocation] = useState(neighborhoods[0]);
  const [reports, setReports] = useState([]);
  const reportsRef = useRef(reports);
  const [loading, setLoading] = useState(false);


  const [posts, setPosts] = useState([]);
  const [communityInput, setCommunityInput] = useState('');

  useEffect(() => {
    reportsRef.current = reports;
  }, [reports]);

  useEffect(() => {
    // Load saved reports at posts mula sa AsyncStorage pag open ng app
  const loadData = async () => {
    try {
      const savedReports = await AsyncStorage.getItem('reports');
      const savedPosts = await AsyncStorage.getItem('posts');
      if (savedReports) setReports(JSON.parse(savedReports));
      if (savedPosts) setPosts(JSON.parse(savedPosts));
    } catch (e) {
      console.log('Failed to load data', e);
    }
  };

  
  loadData();
}, []);


  //Save data when reports or posts change
  useEffect(() => {
      // Save reports sa AsyncStorage tuwing magbabago ang reports state
  AsyncStorage.setItem('reports', JSON.stringify(reports)).catch(console.log);
}, [reports]);

useEffect(() => {
    // Save posts sa AsyncStorage tuwing magbabago ang posts state
  AsyncStorage.setItem('posts', JSON.stringify(posts)).catch(console.log);
}, [posts]);


  // Notify user if incident is nearby
  useEffect(() => {
  if (reports.length === 0) return;

  const normalizedUserArea = userArea.trim().toLowerCase();
  const filteredReports = reports.filter(
    (r) => r.location.trim().toLowerCase() === normalizedUserArea
  );

  if (filteredReports.length === 0) return;

  const latest = filteredReports[0];

  Alert.alert(
    '🚨 Incident Nearby!',
    `${latest.location}: ${latest.description}`,
    [{ text: 'Got it', style: 'default' }]
  );
}, [reports, userArea]);


  // *** INSERT THIS NEW useEffect HERE ***
  useEffect(() => {
    console.log('Reports for current user area:', reports.filter(r => r.location === userArea));
  }, [reports, userArea]);

  // Function to get current location
  const getCurrentLocation = async () => {
    console.log('Getting location...');
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission Denied', 'Location permission is required to report incident.');
      return null;
    }
    const location = await Location.getCurrentPositionAsync({});
    console.log('Location received:', location);

    return {
      latitude: location.coords.latitude,
      longitude: location.coords.longitude,
    };
  };

  // Submit report with current location
  const submitReport = async () => {
     console.log('SUBMITTING REPORT...');
     console.log('Current reports:', reportsRef.current);


    if (!description.trim()) {
      Alert.alert('Oops!', 'Please describe the incident.');
      return;
    }
    
  setLoading(true); // 👉 Start loading spinner
    const coords = await getCurrentLocation();

     if (!coords || !coords.latitude || !coords.longitude) {
     console.log('No valid coordinates retrieved.');
     setLoading(false); // 👉 Stop spinner if failed
    Alert.alert('Location Error', 'Could not get your current location. Please try again.');
    return;
  }

  // Sa submitReport, siguraduhin walang spaces, lowercase:
const normalizedLocation = reportLocation.trim().toLowerCase();

    const newReport = {
      id: Date.now().toString(),
      description: description.trim(),
      timestamp: new Date(),
      location: normalizedLocation,  // save location in lowercase trimmed
      latitude: coords?.latitude,
      longitude: coords?.longitude,
    };

    // Pag filter sa map at alert:
const filteredReports = reports.filter(
  (r) => r.location.trim().toLowerCase() === userArea.trim().toLowerCase()
  );
      console.log('NEW REPORT:', newReport);

    setReports([newReport, ...reportsRef.current]);
console.log('Updated reports:', [newReport, ...reportsRef.current]);

    setDescription('');
    Keyboard.dismiss();
    setLoading(false); // 👉 Done loading

    
  // <-- Add alert here
  Alert.alert('Success!', 'Incident reported successfully.');
  };

  // Add community post
  const addPost = () => {
    if (!communityInput.trim()) return;
    const newPost = {
      id: Date.now().toString(),
      content: communityInput.trim(),
      timestamp: new Date(),
    };
    setPosts([newPost, ...posts]);
    setCommunityInput('');
  };

  // Render functions for lists
  const renderReportItem = ({ item }) => (
    <TouchableOpacity
    onLongPress={() => deleteReport(item.id)} // Long press para mag-delete
    delayLongPress={500} // Delay para hindi madaling mag-trigger
  >
    
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <MaterialIcons name="location-on" size={20} color="#e63946" />
        <Text style={styles.cardLocation}>{item.location}</Text>
        <Text style={styles.cardTime}>{formatDateTime(item.timestamp)}</Text>
      </View>
      <Text style={styles.cardDescription}>{item.description}</Text>
    </View>
    </TouchableOpacity>
  );

  const renderPostItem = ({ item }) => (
      <TouchableOpacity
    onLongPress={() => deletePost(item.id)} // Long press para mag-delete
    delayLongPress={500}
  >
    <View style={styles.postCard}>
      <Text style={styles.postContent}>{item.content}</Text>
      <Text style={styles.postTime}>{formatDateTime(item.timestamp)}</Text>
    </View>
    </TouchableOpacity>
  );

// Delete report by id
const deleteReport = (id) => {
  Alert.alert(
    'Confirm Delete',
    'Are you sure you want to delete this report?',
    [
      { text: 'Cancel', style: 'cancel' },
      { 
        text: 'Delete', 
        style: 'destructive', 
        onPress: () => {
        setReports((prevReports) => prevReports.filter(report => report.id !== id));
      }
    },
  ]
);
};  

// Delete post by id
const deletePost = (id) => {
  Alert.alert(
    'Confirm Delete',
    'Are you sure you want to delete this post?',
    [
      { text: 'Cancel', style: 'cancel' },
      { 
        text: 'Delete', 
        style: 'destructive', 
        onPress: () => {
          setPosts((prevPosts) => prevPosts.filter(post => post.id !== id));
      }
    },
  ]
);
};

return (
  <ImageBackground
    source={{
      uri: 'https://images.unsplash.com/photo-1517328894681-0f5dfabd463c?fm=jpg&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8bmlnaHQlMjBjaXR5JTIwYmFja2dyb3VuZHxlbnwwfHwwfHx8MA%3D%3D&ixlib=rb-4.1.0&q=60&w=3000',
    }}
    style={styles.background}
  >
    <View style={{ backgroundColor: 'rgba(0,0,0,0.5)', flex: 1 }}>
      {/* Header */}
      <View style={styles.header}>
        <MaterialIcons name="security" size={36} color="#fff" />
        <Text style={styles.headerTitle}>Criminal Alert</Text>
      </View>

 {/* Main Content */}
    <FlatList
      data={reports.filter((r) => r.location === userArea)}
      keyExtractor={(item) => item.id}
      renderItem={renderReportItem}
      contentContainerStyle={{ padding: 20, paddingBottom: 40 }}

  ListHeaderComponent={
    <>
    {/* Neighborhood Selection */}
    <Text style={styles.label}>Your Neighborhood</Text>
    <View style={styles.tagContainer}>
      {Object.keys(neighborhoods).map((n) => (
        <TouchableOpacity
          key={n}
          style={[styles.tag, userArea === n && styles.tagSelected]}
          onPress={() => setUserArea(n)}
          activeOpacity={0.8}
        >
          <Text style={[styles.tagText, userArea === n && styles.tagTextSelected]}>
            {n}
          </Text>
        </TouchableOpacity>
      ))}
    </View>

    {/* Incident Location Selection */}
    <Text style={styles.label}>Incident Location</Text>
    <View style={styles.tagContainer}>
      {Object.keys(neighborhoods).map((n) => (
        <TouchableOpacity
          key={n}
          style={[styles.tag, reportLocation === n && styles.tagSelected]}
          onPress={() => setReportLocation(n)}
          activeOpacity={0.8}
        >
          <Text style={[styles.tagText, reportLocation === n && styles.tagTextSelected]}>
            {n}
          </Text>
        </TouchableOpacity>
      ))}
    </View>

    {/* Description */}
    <TextInput
      placeholder="Describe suspicious activity..."
      placeholderTextColor="#999999"
      value={description}
      onChangeText={setDescription}
      style={styles.input}
      multiline
    />

    {/* Report Button */}
    <TouchableOpacity
      style={styles.reportButton}
      onPress={submitReport}
      activeOpacity={0.85}
    >
      <Text style={styles.buttonText}>🚨 Report Incident</Text>
    </TouchableOpacity>

    {/* Map */}
<Text style={styles.subtitle}>Map of Incidents in {userArea}</Text>
<MapView
  style={{ height: 250, marginVertical: 10, borderRadius: 10 }}
  region={{
    latitude: neighborhoods[userArea]?.latitude || 14.4239,
    longitude: neighborhoods[userArea]?.longitude || 121.0415,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  }}
>
  {reports
    .filter(
      (incident) =>
        incident.location?.trim().toLowerCase() === userArea?.trim().toLowerCase()
    )
    .map((incident) => (
    <Marker
      key={incident.id}
      coordinate={{
        latitude: incident.latitude || 14.4239,
        longitude: incident.longitude || 121.0415,
      }}
    >
    <View
      style={{
        width: 30,
        height: 30,
        borderRadius: 15,
        backgroundColor: 'red',
        borderWidth: 3,
        borderColor: 'white',
      }}
    />
  <Callout>
  <View style={{ padding: 5, maxWidth: 200 }}>
    <Text style={{ fontWeight: 'bold', fontSize: 16 }}>
      {incident.location}
    </Text>
    <Text style={{ marginTop: 4 }}>{incident.description}</Text>
    <Text style={{ marginTop: 6, fontSize: 12, color: '#555' }}>
      {formatDateTime(new Date(incident.timestamp))}
    </Text>
  </View>
</Callout>
</Marker>
))}
</MapView>

{/* ✅ Show spinner/loading/waiting + Incident List*/}
<Text style={styles.subtitle}>Incidents in your area ({userArea})</Text>
{loading ? (
  <ActivityIndicator size="large" color="#fff" style={{ marginVertical: 20 }} />
) : reports.filter(
  (r) => r.location?.trim().toLowerCase() === userArea?.trim().toLowerCase()
).length === 0 ? (
  <Text style={styles.noReports}>No incidents reported yet.</Text>
) : (
  <FlatList
    data={reports.filter(
      (r) => r.location?.trim().toLowerCase() === userArea?.trim().toLowerCase()
    )}
    keyExtractor={(item) => item.id}
    renderItem={renderReportItem}
    scrollEnabled={false}
    contentContainerStyle={{ paddingBottom: 20 }}
  />
)}
    
    </>
  }
  ListFooterComponent={
    <>
      {/* Community Section */}
      <Text style={styles.subtitle}>Community Space</Text>
      <View style={styles.communityInputContainer}>
        <TextInput
          placeholder="Share community update..."
          value={communityInput}
          onChangeText={setCommunityInput}
          style={styles.communityInput}
          onSubmitEditing={addPost}
          returnKeyType="send"
        />
        <TouchableOpacity onPress={addPost} style={styles.sendButton}>
          <MaterialIcons name="send" size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      {posts.length === 0 ? (
        <Text style={styles.noReports}>No community posts yet.</Text>
      ) : (
        <FlatList
          data={posts}
          keyExtractor={(item) => item.id}
          renderItem={renderPostItem}
          scrollEnabled={false} // Important: disable internal scroll
        />
      )}
    </>
  }
/>
      </View>
    </ImageBackground>
  );
}

//Stylesheets

const styles = StyleSheet.create({
  background:{
    flex: 1,
    resizeMode: 'cover',
  },
  header:{
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingVertical: 20,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 15,
    borderBottomRightRadius: 15,
  },
  headerTitle:{
    fontSize: 26,
    fontWeight: 'bold',
    color: '#fff',
    marginLeft: 10,
  },
  container:{
    padding: 20,
  },
  label:{
    fontSize: 17,
    fontWeight: '700',
    color: '#f1f1f1',
    marginBottom: 8,
  },
  tagContainer:{
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 15,
  },
  tag:{
    borderWidth: 1,
    borderColor: '#fff',
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 14,
    marginRight: 10,
    marginBottom: 10,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  tagSelected:{
    backgroundColor: '#ff6f61',
    borderColor: '#ff6f61',
  },
  tagText:{
    color: '#fff',
    fontWeight: '600',
  },
  tagTextSelected:{
    color: '#fff',
  },
  input:{
    backgroundColor: 'rgba(255,255,255,0.9)',
    borderRadius: 15,
    padding: 15,
    fontSize: 16,
    minHeight: 80,
    marginBottom: 15,
    color: '#333',
  },
  reportButton:{
    backgroundColor: '#00b4d8',
    paddingVertical: 15,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  buttonText:{
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
  },
  subtitle:{
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fefefe',
    marginTop: 10,
    marginBottom: 10,
  },
  noReports:{
    fontSize: 14,
    color: '#ddd',
    fontStyle: 'italic',
    textAlign: 'center',
    marginTop: 20,
  },
  card:{
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 10,
    elevation: 4,
  },
  cardHeader:{
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardLocation:{
    fontSize: 14,
    fontWeight: '600',
    color: '#e63946',
    marginLeft: 8,
  },
  cardTime:{
    fontSize: 12,
    color: '#555',
    marginLeft: 'auto',
  },
  cardDescription:{
    fontSize: 14,
    color: '#333',
  },
  communityInputContainer:{
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  communityInput:{
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.9)',
    borderRadius: 15,
    padding: 12,
    fontSize: 16,
    marginRight: 10,
  },
  sendButton:{
    backgroundColor: '#00b4d8',
    padding: 10,
    borderRadius: 50,
  },
  postCard:{
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 4,
  },
  postContent:{
    fontSize: 14,
    marginBottom: 8,
  },
  postTime:{
    fontSize: 12,
    color: '#555',
    alignSelf: 'flex-end',
  },
});
